from .kerucut import *
from .tabung import *
from .BOLA1 import *
from .Limas import *
from .kubusBalok import *
from .prisma import *
