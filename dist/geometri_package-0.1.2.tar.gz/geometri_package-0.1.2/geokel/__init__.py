from .BOLA1 import *
from .kerucut import *
from .kubusBalok import *
from .Limas import *
from .prisma import *
from .tabung import *